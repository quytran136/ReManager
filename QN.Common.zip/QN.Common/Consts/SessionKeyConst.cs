﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Consts
{
    public static class SessionKeyConst
    {
        public const string USER = "USER_LOGIN";
    }
}
