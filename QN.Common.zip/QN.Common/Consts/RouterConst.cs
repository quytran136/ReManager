﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Consts
{
    public class RouterConst
    {
        // Controllers
        public const string Home = "Home";
        public const string User = "User";

        // actions
        public const string Index = "Index";
        public const string Edit = "Edit";
        public const string Delete = "Delete";

    }
}
