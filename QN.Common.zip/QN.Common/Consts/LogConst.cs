﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Consts
{
    public static class LogConst
    {
        internal const string LOG_FILE_NAME = "{0}_{1}_{2}";
        public const string KEY_SYSTEM = "SysEx";
        public const string KEY_BUSINESS = "BusEx";
        public const string KEY_ERR = "Error";
        public const string KEY_WARN = "Warning";
        public const string KEY_NORMAL = "Normal";
    }
}
