﻿using QN.Common.Consts;
using QN.Common.Properties;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace QN.Common.Handle
{
    public class LogHandle
    {
        public static void WriteLog(string UserID,string key, string content)
        {
            new Thread(() => {
                try
                {
                    string logTemp = Resources.LogTemp;
                    logTemp = logTemp.Replace("{{KEY}}",key);
                    logTemp = logTemp.Replace("{{DATE}}",DateTime.Now.ToString());
                    logTemp = logTemp.Replace("{{USER_ACCESS}}",UserID);
                    logTemp = logTemp.Replace("{{CONTENT}}", content);
                    File.AppendAllText(WebConfigurationManager.AppSettings["Log"] + "\\" + key + "\\" + string.Format(LogConst.LOG_FILE_NAME,DateTime.Now.Date.ToString("yyyyMMdd"), key, DateTime.Now.Hour) + ".log", logTemp);
                }
                catch (Exception ex)
                {
                    throw new QNSystemException(UserID,"Không thể ghi log", ex);
                }
            }).Start();
    }
}
}
