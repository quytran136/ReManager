﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Handle
{
    public class EncryptionHandle
    {
        public string Encryption(string password)
        {
            int iterations = 3000;
            try
            {
                if (string.IsNullOrEmpty(password))
                {
                    throw new QNBusinessException("System", "Không thể thực hiện mã hóa do mật khẩu trống hoặc không có.");
                }

                var rfc = new Rfc2898DeriveBytes(password, 64, iterations, HashAlgorithmName.SHA256);
                return Convert.ToBase64String(rfc.GetBytes(64));
            }
            catch (QNBusinessException busEx)
            {
                throw new QNBusinessException("System", busEx.Message, busEx);
            }
        }
    }
}
