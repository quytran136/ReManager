﻿using QN.Common.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Handle
{
    public class QNSystemException : Exception
    {
        public QNSystemException()
        {
        }

        public QNSystemException(string userId, string message) : base(message)
        {
            LogHandle.WriteLog(userId, LogConst.KEY_SYSTEM, message);
        }

        /// <summary>
        /// create exception with param
        /// </summary>
        /// <param name="message"></param>
        /// <param name="param"></param>
        public QNSystemException(string userId, string message, params object[] param) : base(string.Format(message, param))
        {
            LogHandle.WriteLog(userId, LogConst.KEY_SYSTEM, string.Format(message, param));
        }

        public QNSystemException(string userId, string message, Exception innerException) : base(message, innerException)
        {
            LogHandle.WriteLog(userId, LogConst.KEY_SYSTEM, message);
        }

        protected QNSystemException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
