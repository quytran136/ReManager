﻿using QN.Common.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace QN.Common.Handle
{
    public class QNBusinessException : Exception
    {
        public QNBusinessException()
        {
        }

        public QNBusinessException(string userId, string message) : base(message)
        {
            LogHandle.WriteLog(userId, LogConst.KEY_BUSINESS, message);
        }

        /// <summary>
        /// create exception with param
        /// </summary>
        /// <param name="message"></param>
        /// <param name="param"></param>
        public QNBusinessException(string userId, string message, params object[] param) : base(string.Format(message, param))
        {
            LogHandle.WriteLog(userId, LogConst.KEY_BUSINESS, string.Format(message, param));
        }

        public QNBusinessException(string userId, string message, Exception innerException) : base(message, innerException)
        {
            LogHandle.WriteLog(userId, LogConst.KEY_BUSINESS, message);
        }

        protected QNBusinessException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
