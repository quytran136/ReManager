﻿using QN.Buz.Models;
using QN.Common.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.ModelBinding;
using System.Web.Mvc;

namespace QN.Controllers
{
    public class UserController : Controller
    {
        [HttpPost]
        public ActionResult Login([Form] UserInfo userInfo)
        {
            if (Session[SessionKeyConst.USER] != null)
            {
                // clear session
                Session.Clear();
            }
            else
            {
                Session[SessionKeyConst.USER] = userInfo.getInfo();
            }
            return RedirectToAction(RouterConst.Index, RouterConst.Home);
        }

        [HttpPost]
        public ActionResult Register([Form] UserInfo userInfo)
        {
            userInfo.Register();
            return RedirectToAction(RouterConst.Index, RouterConst.Home);
        }

        [HttpPost]
        public ActionResult Logout()
        {
            if (Session[SessionKeyConst.USER] != null)
            {
                Session.Remove(SessionKeyConst.USER);
            }
            return RedirectToAction(RouterConst.Index, RouterConst.Home);
        }
    }
}