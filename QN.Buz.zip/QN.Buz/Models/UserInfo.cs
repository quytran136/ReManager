﻿using QN.Buz.Models.Attributes;
using QN.Common.Consts;
using QN.Common.Handle;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QN.Buz.Models
{
    public class UserInfo
    {
        private string email = string.Empty;
        private string pass = string.Empty;
        private string repass = string.Empty;
        private DateTime birth = new DateTime();
        private string name = string.Empty;
        private bool sex = true;
        private string haspassword = string.Empty;

        [ValidationModel(CheckWhireSpace = true)]
        public string Email1 { get => email; set => email = value; }

        [ValidationModel(CheckWhireSpace = true)]
        public string Password1 { get => pass; set => pass = value; }
        
        [ValidationModel(CheckWhireSpace = true)]
        public string Repass { get => repass; set => repass = value; }

        [ValidationModel(CheckWhireSpace = false)]
        public DateTime Birth { get => birth; set => birth = value; }
        
        [ValidationModel(CheckWhireSpace = false)]
        public string Name { get => name; set => name = value; }
        
        [ValidationModel(CheckWhireSpace = false)]
        public bool Sex { get => sex; set => sex = value; }
        
        public string Haspassword { get => haspassword; set => haspassword = value; }

        public void isLoginValidation(string email, string pass)
        {
            // check password
            EncryptionHandle encryptionHandle = new EncryptionHandle();
            string hashPassword = encryptionHandle.Encryption(pass);
            LogHandle.WriteLog("UserID", LogConst.KEY_NORMAL, hashPassword);
        }

        public UserInfo getInfo()
        {
            return this;
        }

        public void Register()
        {
            try
            {
                
            }
            catch (QNBusinessException ex)
            {
                throw new QNBusinessException();
            }
        }
    }
}