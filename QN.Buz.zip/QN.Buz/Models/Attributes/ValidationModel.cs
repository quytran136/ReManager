﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QN.Buz.Models.Attributes
{
    public class ValidationModel : ValidationAttribute
    {
        private bool checkWhireSpace = false;

        public bool CheckWhireSpace { get => checkWhireSpace; set => checkWhireSpace = value; }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                return null;
            }
            switch (Type.GetTypeCode(value.GetType()))
            {
                case TypeCode.String:
                    if (string.IsNullOrEmpty(value.ToString()))
                    {
                        ErrorMessage = "Không được để trống giá trị";
                    }
                    if (CheckWhireSpace == true)
                    {
                        if (string.IsNullOrWhiteSpace(value.ToString()))
                        {
                            ErrorMessage = "Giá trị không được tồn tại khoảng trắng";
                        }
                    }
                    break;
                default:
                    if (value == null)
                    {
                        ErrorMessage = "Không được để trống giá trị";
                    }
                    break;
            }
            return new ValidationResult(ErrorMessage);
        }
    }
}
